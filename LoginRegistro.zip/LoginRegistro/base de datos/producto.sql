-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 16-08-2022 a las 14:25:15
-- Versión del servidor: 8.0.30-0ubuntu0.20.04.2
-- Versión de PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbd_hotys`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int UNSIGNED NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `precio` double(10,2) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `in_activo` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `descripcion`, `precio`, `foto`, `in_activo`) VALUES
(14, 'BLACK TONIC', 40.00, 'http://localhost/php/Frondent-main/LoginRegistro/proyecto/views/assets/imgs/shop/pr34.jpeg', 1),
(15, 'BODY GUARD', 40.00, 'http://localhost/php/Frondent-main/LoginRegistro/proyecto/views/assets/imgs/shop/pr41.jpeg', 1),
(16, 'MISCHIEF', 40.00, 'http://localhost/php/Frondent-main/LoginRegistro/proyecto/views/assets/imgs/shop/pr35.jpeg', 1),
(17, 'BIG OCEAN', 40.00, 'http://localhost/php/Frondent-main/LoginRegistro/proyecto/views/assets/imgs/shop/pr40.jpeg', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
