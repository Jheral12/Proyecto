<?php
require_once "connection.php";

	class ProductoModels
	{


			// Listar productos
			public static function LstAllProducto(){
				// Prepare
				$stmt = connection::conex()->prepare("SELECT * FROM producto order by id desc");
				$stmt->execute();
				$NuRegistros = $stmt->rowCount();

				if ($NuRegistros > 0 ) { 
						return $stmt->fetchAll();
						}

				else{return false;}
				
			}

			// Ingresa producto
			public static function AddProducto(){
				// Prepare
				$stmt = connection::conex()->prepare("INSERT INTO producto (descripcion, precio , foto) VALUES (:descripcion, :precio, :foto)");
				// Bind
				$descripcion = $_POST["descripcion"];
				$precio = $_POST["precio"];
				$foto = $_POST["foto"];
				$stmt->bindParam(':descripcion', $descripcion);
				$stmt->bindParam(':precio', $precio);
				$stmt->bindParam(':foto', $foto);

				if ($stmt->execute()) { 

					$count = $stmt->rowCount();
						if ($count==1){
							return true;
						}
						else{	return false;}
				} else {
			
						return false;
		
				}

			}

			// Ingresa producto
			public static function UpdProducto(){
				// Prepare
				$stmt = connection::conex()->prepare("UPDATE producto SET descripcion=:descripcion, precio=:precio, foto=:foto WHERE id=:id");
				// Bind
				$id = $_POST["idupdproducto"];
				$descripcion = $_POST["descripcion"];
				$precio = $_POST["precio"];
				$foto = $_POST["foto"];
				$stmt->bindParam(':id', $id);
				$stmt->bindParam(':descripcion', $descripcion);
				$stmt->bindParam(':precio', $precio);
				$stmt->bindParam(':foto', $foto);

				if ($stmt->execute()) { 

					$count = $stmt->rowCount();
						if ($count==1){
							return true;
						}
						else{	return false;}
				} else {
			
						return false;
		
				}

			}

			// Ingresa producto
			public static function DelProducto(){
				// Prepare
				$stmt = connection::conex()->prepare("DELETE FROM producto WHERE id=:id");
				// Bind
				$id = $_POST["iddelproducto"];
				$stmt->bindParam(':id',$id);


				if ($stmt->execute()) { 

					$count = $stmt->rowCount();
						if ($count==1){
							return true;
						}
						else{	return false;}
				} else {
			
						return false;
		
				}

			}
}
?>