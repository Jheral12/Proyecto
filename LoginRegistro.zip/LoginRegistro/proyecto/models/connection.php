<?php
class connection{
	public static function conex(){
		$link = new PDO("mysql:host=localhost;dbname=login","root","123456");
		return $link;
	}
}