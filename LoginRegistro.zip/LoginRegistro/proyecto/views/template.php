<!DOCTYPE html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8" />
		<title>HOTY'S</title>
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta property="og:title" content="" />
		<meta property="og:type" content="" />
		<meta property="og:url" content="" />
		<meta property="og:image" content="" />
		<!-- Favicon -->
		<link rel="shortcut icon" type="image/x-icon" href="views/assets/imgs/theme/1.png" />

		<!-- Template CSS -->
		<link rel="stylesheet" href="views/assets/css/plugins/animate.min.css" />
		<link rel="stylesheet" href="views/assets/css/main.css?v=2.0" />
	</head>
        <body>
			<!-- Preloader Start -->
			<!-- <div id="preloader-active">
				<div class="preloader d-flex align-items-center justify-content-center">
					<div class="preloader-inner position-relative">
						<div class="text-center">
							<img src="views/assets/imgs/theme/perfum.gif" alt="" />
						</div>
					</div>
				</div>
			</div> -->
			<!-- Vendor JS-->
            <main class="main">
                <?php
                    $modulos=new Enlaces();
                    $modulos->enlacesController();
                ?>
            </main>
        </body>
    </body>
</html>