<?php include"views/modules/header.php"; ?>
<div class="container" style="padding-top: 50px; padding-bottom:50px;">
    <div class="row">
        <div class="col-lg-12">
            <img class="img-fluid" src="views/assets/imgs/page/page-404.png" style="display:block; margin: auto;">
        </div>
    </div>
</div>
<?php include"views/modules/footer.php"; ?>