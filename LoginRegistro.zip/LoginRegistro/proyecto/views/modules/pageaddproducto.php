﻿<?php
if(!isset($_SESSION["cliente"])){
	header("location:pagelogin");
	exit();
}
?>
<?php include "views/modules/header.php"; ?>
            <div class="page-header breadcrumb-wrap">
                <div class="container">
                    <div class="breadcrumb">
                        <a href="index" rel="nofollow"><i class="fi-rs-home mr-5"></i>Hogar</a>
                        <span></span>Paginas<span></span>Registro
                    </div>
                </div>
            </div>
            <div class="page-content pt-150 pb-150">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 col-lg-10 col-md-12 m-auto">
                            <div class="row">
                                <div class="col-lg-6 col-md-8">
                                    <div class="login_wrap widget-taber-content background-white">
                                        <div class="padding_eight_all bg-white">
                                            <div class="heading_s1">
                                                <h1 class="mb-5">Crear Producto</h1>
                         
                                            </div>
                                            <form method="post">
                                                <?php
                                                    $addproducto = Producto::addProductoController();
                                         
                                                    if(!empty($addproducto)){
                                                        if ($addproducto['status']!='') {
                                                            ?>
                                                            <div class="alert alert-<?php echo $addproducto['status'];?>" role="alert">
                                                             <?php echo $ingreso['detail'];?>
                                                            </div>
                                                            <?php if ($addproducto['status']=='success') {?>
                                                            <script>
                                                                setTimeout("location.href='dashboard'", 0);
                                                            </script>
                                                            <?php } ?>

                                                            <?php
                                                        }
                                                    }

                                                ?>

                                                <div class="form-group">
                                                    <input type="text" required="" name="descripcion" placeholder="Titulo" />
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" required="" name="precio" placeholder="precio" />
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" required="" name="foto" placeholder="link de foto" />
                                                </div>
        
                                                <div class="form-group mb-30">
                                                    <button type="submit" class="btn btn-fill-out btn-block hover-up font-weight-bold" name="producto">Agregar</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                  </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include "views/modules/footer.php"; ?>