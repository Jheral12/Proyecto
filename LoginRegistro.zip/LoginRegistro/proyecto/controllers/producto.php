<?php
class producto{

	public static function LstAllProductoController(){

		$respuesta = ProductoModels::LstAllProducto();
                 if (!$respuesta) {
                    return false;

                }else{
                    return $respuesta;
				}

					
	
	}

	public static function addProductoController(){
		if(isset($_POST["producto"])){
		
				$data = array("descripcion"=>$_POST["descripcion"],"precio"=>$_POST["precio"],"foto"=>$_POST["foto"]);
				$respuesta = ProductoModels::AddProducto($data);
                 if ($respuesta) {
                    return array('status'=>'success', 'detail'  =>'Producto Registrado Satisfactoriamente');

                }else{
                    return array('status'=>'danger', 'detail'    =>'Producto no pudo ser registrado');
				}

					
		}
	}

	public static function updProductoController(){
		if(isset($_POST["idupdproducto"])){
		
				$data = array("id"=>$_POST["idupdproducto"],"descripcion"=>$_POST["descripcion"],"precio"=>$_POST["precio"],"foto"=>$_POST["foto"]);
				$respuesta = ProductoModels::UpdProducto($data);
                 if ($respuesta) {
                    return array('status'=>'success', 'detail'  =>'Producto Actualizado Satisfactoriamente');

                }else{
                    return array('status'=>'danger', 'detail'    =>'Producto no pudo ser actualizado');
				}

					
		}
	}

	public static function delProductoController(){
		if(isset($_POST["iddelproducto"])){
		
			//	$data = array("id"=>$_POST["iddelproducto"]);
				$respuesta = ProductoModels::DelProducto();
                 if ($respuesta) {
                    return array('status'=>'success', 'detail'  =>'Producto Borrado Satisfactoriamente');

                }else{
                    return array('status'=>'danger', 'detail'    =>'Producto no pudo ser borrado');
				}

					
		}
	}


}
